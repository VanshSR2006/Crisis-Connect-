import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useOfficerContext } from '@/lib/officerContext';
import { SeverityBadge } from '@/components/shared/SeverityBadge';
import { Activity, Droplets, Waves, TrendingUp, AlertTriangle, ShieldAlert, Layers, MousePointerClick } from 'lucide-react';

export const RiskHeatmap: React.FC = () => {
  const { t } = useTranslation();
  const { riskZones, isLoadingRisk, isErrorRisk, selectedZoneId, setSelectedZoneId } = useOfficerContext();

  const highestScore = riskZones.length > 0 ? Math.max(...riskZones.map((s) => s.score)) : 0;
  const activeZone = selectedZoneId ? riskZones.find((s) => s.zone_id === selectedZoneId) || null : null;

  const getHeatColor = (score: number) => {
    if (score >= 85) return 'bg-red-600 text-white border-red-500 shadow-red-900/50';
    if (score >= 70) return 'bg-orange-600 text-white border-orange-500 shadow-orange-900/50';
    if (score >= 40) return 'bg-amber-500/30 text-amber-200 border-amber-500/70 font-semibold';
    return 'bg-emerald-800/60 text-emerald-100 border-emerald-600';
  };

  return (
    <div className="space-y-5">
      {/* ── Page Header ──────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-[#1b1b1d]" style={{ letterSpacing: '-0.02em' }}>
            {t('officer.riskHeatmap.title')}
          </h1>
          <p className="text-[13px] text-[#45464d] mt-0.5">
            {t('officer.riskHeatmap.subtitle')} · {riskZones.length} {t('officer.riskHeatmap.zonesMonitored')}
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#45464d]">
          <Activity className="h-3.5 w-3.5 text-[#c2410c] animate-pulse" />
          <span>{t('officer.riskHeatmap.aiModelActive')}</span>
        </div>
      </div>

      {/* ── Risk Summary Alert ────────────────────────────── */}
      <div className="bg-[#ffedd5] border border-[#fdba74] text-[#c2410c] rounded p-3 flex items-start gap-3 shadow-sm">
        <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-xs font-bold uppercase tracking-wide">
            {t('officer.riskHeatmap.criticalFloodWarning')}
          </p>
          <p className="text-[12px] text-[#9a3412] mt-0.5">
            Maximum risk score detected is <strong className="font-mono">{highestScore}/100</strong> across monitored zones.
          </p>
        </div>
      </div>

      {/* ── Dark Command Center Visual Heatmap Matrix ───────── */}
      <div className="bg-[#0f172a] text-white border border-slate-800 rounded p-4 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-blue-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              {t('officer.riskHeatmap.spatialVulnerabilityMatrix')}
            </h2>
          </div>

          {/* Heat Legend */}
          <div className="flex items-center gap-3 text-[10px]">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-red-600 inline-block" /> Severe (&gt;85)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-orange-600 inline-block" /> High (70-85)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-400 inline-block" /> Advisory (40-70)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-800 inline-block" /> Low (&lt;40)
            </span>
          </div>
        </div>

        {/* Heatmap Grid Cells */}
        {isLoadingRisk ? (
          <div className="py-10 text-center text-slate-400">Loading risk data...</div>
        ) : isErrorRisk ? (
          <div className="py-10 text-center text-red-500">Failed to load risk zones.</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {riskZones.map((zone) => {
              const isSelected = selectedZoneId === zone.zone_id;
              return (
                <button
                  key={zone.id}
                  onClick={() => setSelectedZoneId(zone.zone_id)}
                  className={`p-3.5 rounded border text-left flex flex-col justify-between transition-all cursor-pointer ${getHeatColor(
                    zone.score
                  )} ${isSelected ? 'ring-4 ring-yellow-400 scale-105 z-10 shadow-lg' : 'hover:opacity-90'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono font-bold uppercase tracking-wide opacity-90 truncate max-w-[80px]">
                      {zone.name}
                    </span>
                    <SeverityBadge severity={zone.risk_level} showIcon={false} />
                  </div>
                  <div className="text-3xl font-black">{zone.score}</div>
                  <span className="text-[10px] font-medium opacity-80 mt-1 block">
                    Pop: {zone.population_est.toLocaleString()}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Selected Zone Metrics Detail Card (or prompt when none selected) ─── */}
      {activeZone ? (
        <div className="bg-white border border-[#c6c6cd] rounded p-4 shadow-sm space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-[#f0edef] pb-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-[#2563eb]" />
              <h3 className="text-xs font-bold uppercase tracking-[0.05em] text-[#1b1b1d]">
                {t('officer.riskHeatmap.detailedAnalysis')} — {t('officer.dashboard.zone')}: <span className="font-mono text-[#0f172a]">{activeZone.zone_id}</span>
              </h3>
            </div>
            <SeverityBadge severity={activeZone.risk_level} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-[#f6f3f5] rounded border border-[#c6c6cd]">
              <span className="text-[10px] font-bold text-[#76777d] uppercase tracking-wider block">
                {t('officer.riskHeatmap.compositeRiskScore')}
              </span>
              <span className="text-2xl font-bold text-[#0f172a] mt-0.5 block">{activeZone.score} / 100</span>
            </div>

            <div className="p-3 bg-[#f6f3f5] rounded border border-[#c6c6cd]">
              <span className="text-[10px] font-bold text-[#76777d] uppercase tracking-wider block flex items-center gap-1">
                <AlertTriangle className="h-3.5 w-3.5 text-[#2563eb]" /> Population at Risk
              </span>
              <span className="text-2xl font-bold text-[#0f172a] mt-0.5 block">{activeZone.population_est.toLocaleString()}</span>
            </div>

            <div className="p-3 bg-[#f6f3f5] rounded border border-[#c6c6cd]">
              <span className="text-[10px] font-bold text-[#76777d] uppercase tracking-wider block flex items-center gap-1">
                <Activity className="h-3.5 w-3.5 text-[#2563eb]" /> Last Updated
              </span>
              <span className="text-sm font-bold text-[#0f172a] mt-2 block">{new Date(activeZone.computed_at).toLocaleString()}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-[#c6c6cd] border-dashed rounded p-6 text-center text-[#76777d] flex flex-col items-center justify-center gap-2">
          <MousePointerClick className="h-6 w-6 text-[#2563eb]" />
          <p className="text-xs font-semibold text-[#1b1b1d]">
            {t('officer.riskHeatmap.noZoneSelected')}
          </p>
          <p className="text-[11px] text-[#76777d]">
            {t('officer.riskHeatmap.clickToInspect')}
          </p>
        </div>
      )}
    </div>
  );
};
